import styled, { css } from "styled-components";

export const Transition = css`
  transition: all 0.7s ease;
`;
